"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { login, register, getCurrentUser } from "@/lib/auth"
import { db } from "@/lib/database"
import type { User } from "@/lib/types"

export default function AuthPage() {
  const [loginType, setLoginType] = useState<"admin" | "cashier" | "customer">("admin")
  const [loginEmail, setLoginEmail] = useState("")
  const [loginPassword, setLoginPassword] = useState("")
  const [loginError, setLoginError] = useState("")
  const [loginLoading, setLoginLoading] = useState(false)
  const [showCashierIdLogin, setShowCashierIdLogin] = useState(false)

  // Register state (for customers only)
  const [registerEmail, setRegisterEmail] = useState("")
  const [registerPassword, setRegisterPassword] = useState("")
  const [registerName, setRegisterName] = useState("")
  const [registerError, setRegisterError] = useState("")
  const [registerSuccess, setRegisterSuccess] = useState("")
  const [registerLoading, setRegisterLoading] = useState(false)

  const router = useRouter()

  useEffect(() => {
    // Initialize sample data
    db.initializeSampleData()

    // Check if user is already logged in
    const user = getCurrentUser()
    if (user) {
      redirectUser(user)
    }
  }, [])

  const redirectUser = (user: User) => {
    if (user.role === "customer") {
      router.push("/customer")
    } else {
      router.push("/admin")
    }
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoginLoading(true)
    setLoginError("")

    try {
      const user = await login(loginEmail, loginPassword, loginType)
      if (user) {
        redirectUser(user)
      } else {
        setLoginError("Invalid credentials")
      }
    } catch (err) {
      setLoginError("Login failed. Please try again.")
    } finally {
      setLoginLoading(false)
    }
  }

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    setRegisterLoading(true)
    setRegisterError("")
    setRegisterSuccess("")

    try {
      const result = await register(registerEmail, registerPassword, registerName, "customer")
      if (result.success) {
        setRegisterSuccess(result.message)
        // Clear form
        setRegisterEmail("")
        setRegisterPassword("")
        setRegisterName("")
      } else {
        setRegisterError(result.message)
      }
    } catch (err) {
      setRegisterError("Registration failed. Please try again.")
    } finally {
      setRegisterLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="text-3xl font-bold text-blue-600 mb-2">MEGRAC</div>
          <CardTitle>Inventory Management System</CardTitle>
          <CardDescription>Sign in to your account or create a new one</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Sign In</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>

            <TabsContent value="login">
              <div className="space-y-4 mb-4">
                <Label>Login as:</Label>
                <Select
                  value={loginType}
                  onValueChange={(value: "admin" | "cashier" | "customer") => {
                    setLoginType(value)
                    setShowCashierIdLogin(false)
                    setLoginEmail("")
                    setLoginPassword("")
                  }}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">Admin</SelectItem>
                    <SelectItem value="cashier">Cashier</SelectItem>
                    <SelectItem value="customer">Customer</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="login-email">Email</Label>
                  <Input
                    id="login-email"
                    type="email"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="Enter your email"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="login-password">{showCashierIdLogin ? "Cashier ID" : "Password"}</Label>
                  <Input
                    id="login-password"
                    type={showCashierIdLogin ? "text" : "password"}
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder={showCashierIdLogin ? "Enter your 8-digit Cashier ID" : "Enter your password"}
                    required
                  />
                </div>

                {loginType === "cashier" && !showCashierIdLogin && (
                  <Button
                    type="button"
                    variant="link"
                    className="p-0 h-auto text-sm"
                    onClick={() => setShowCashierIdLogin(true)}
                  >
                    I can't remember password
                  </Button>
                )}

                {showCashierIdLogin && (
                  <Button
                    type="button"
                    variant="link"
                    className="p-0 h-auto text-sm"
                    onClick={() => setShowCashierIdLogin(false)}
                  >
                    Use email instead
                  </Button>
                )}

                {loginError && <div className="text-red-500 text-sm text-center">{loginError}</div>}
                <Button type="submit" className="w-full" disabled={loginLoading}>
                  {loginLoading ? "Signing in..." : "Sign In"}
                </Button>
              </form>

              <div className="mt-6 p-4 bg-muted rounded-lg">
                <p className="text-sm font-medium mb-2">Demo Account:</p>
                <div className="text-xs space-y-1">
                  <div>
                    <strong>Admin:</strong> megracadmin@gmail.com (Password: admin123)
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="register">
              <p className="text-sm text-muted-foreground mb-4">
                Customer registration only. Cashier accounts are created by admin.
              </p>
              <form onSubmit={handleRegister} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="register-name">Full Name</Label>
                  <Input
                    id="register-name"
                    type="text"
                    value={registerName}
                    onChange={(e) => setRegisterName(e.target.value)}
                    placeholder="Enter your full name"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="register-email">Email</Label>
                  <Input
                    id="register-email"
                    type="email"
                    value={registerEmail}
                    onChange={(e) => setRegisterEmail(e.target.value)}
                    placeholder="Enter your email"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="register-password">Password</Label>
                  <Input
                    id="register-password"
                    type="password"
                    value={registerPassword}
                    onChange={(e) => setRegisterPassword(e.target.value)}
                    placeholder="Enter your password"
                    required
                  />
                </div>
                {registerError && <div className="text-red-500 text-sm text-center">{registerError}</div>}
                {registerSuccess && <div className="text-green-500 text-sm text-center">{registerSuccess}</div>}
                <Button type="submit" className="w-full" disabled={registerLoading}>
                  {registerLoading ? "Creating Account..." : "Create Customer Account"}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
