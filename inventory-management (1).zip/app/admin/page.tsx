"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { getCurrentUser, isAdminOrCashier } from "@/lib/auth"
import { AdminSidebar } from "@/components/admin-sidebar"
import { DashboardStats } from "@/components/dashboard-stats"
import { InventoryManagement } from "@/components/inventory-management"
import { SalesManagement } from "@/components/sales-management"
import { TransactionRecords } from "@/components/transaction-records"
import { PurchaseManagement } from "@/components/purchase-management"
import { CashierManagement } from "@/components/cashier-management"
import { CustomerAccountsManagement } from "@/components/customer-accounts-management"

export default function AdminPage() {
  const [activeSection, setActiveSection] = useState("dashboard")
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const user = getCurrentUser()
    if (!user || !isAdminOrCashier()) {
      router.push("/")
      return
    }
    setLoading(false)
  }, [router])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg">Loading...</div>
      </div>
    )
  }

  const renderContent = () => {
    switch (activeSection) {
      case "dashboard":
        return (
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
              <p className="text-gray-600 mt-2">Welcome to your inventory management system</p>
            </div>
            <DashboardStats />
          </div>
        )
      case "inventory":
        return <InventoryManagement />
      case "sales":
        return <SalesManagement />
      case "purchases":
        return <PurchaseManagement />
      case "customers":
        return (
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Customer Management</h1>
              <p className="text-gray-600 mt-2">Manage customer information and history</p>
            </div>
            <div className="bg-white p-8 rounded-lg border">
              <p className="text-center text-gray-500">
                Customer management features are available through the sales system
              </p>
            </div>
          </div>
        )
      case "suppliers":
        return (
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Supplier Management</h1>
              <p className="text-gray-600 mt-2">Manage supplier information and relationships</p>
            </div>
            <div className="bg-white p-8 rounded-lg border">
              <p className="text-center text-gray-500">
                Supplier management features are available through the purchase system
              </p>
            </div>
          </div>
        )
      case "transactions":
        return <TransactionRecords />
      case "cashiers":
        return <CashierManagement />
      case "customer-accounts":
        return <CustomerAccountsManagement />
      default:
        return <DashboardStats />
    }
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <AdminSidebar activeSection={activeSection} onSectionChange={setActiveSection} />
      <main className="flex-1 p-8">{renderContent()}</main>
    </div>
  )
}
