"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { getCurrentUser } from "@/lib/auth"
import { CustomerSidebar } from "@/components/customer-sidebar"
import { CustomerShopping } from "@/components/customer-shopping"
import { CustomerPurchases } from "@/components/customer-purchases"
import { CustomerInventory } from "@/components/customer-inventory"

export default function CustomerPage() {
  const [activeSection, setActiveSection] = useState("sales")
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const user = getCurrentUser()
    if (!user || user.role !== "customer") {
      router.push("/")
      return
    }
    setLoading(false)
  }, [router])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg">Loading...</div>
      </div>
    )
  }

  const renderContent = () => {
    switch (activeSection) {
      case "sales":
        return <CustomerShopping />
      case "purchases":
        return <CustomerPurchases />
      case "inventory":
        return <CustomerInventory />
      default:
        return <CustomerShopping />
    }
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <CustomerSidebar activeSection={activeSection} onSectionChange={setActiveSection} />
      <main className="flex-1 p-8">{renderContent()}</main>
    </div>
  )
}
