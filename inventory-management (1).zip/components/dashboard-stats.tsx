"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { db } from "@/lib/database"
import { Package, ShoppingCart, Users, TrendingUp } from "lucide-react"

export function DashboardStats() {
  const [stats, setStats] = useState({
    totalProducts: 0,
    totalSales: 0,
    totalCustomers: 0,
    lowStockItems: 0,
    todaySales: 0,
    totalRevenue: 0,
  })

  useEffect(() => {
    const products = db.getProducts()
    const sales = db.getSales()
    const customers = db.getCustomers()

    const today = new Date()
    today.setHours(0, 0, 0, 0)

    const todaySales = sales.filter((sale) => {
      const saleDate = new Date(sale.saleDate)
      saleDate.setHours(0, 0, 0, 0)
      return saleDate.getTime() === today.getTime()
    })

    const totalRevenue = sales.reduce((sum, sale) => sum + sale.total, 0)
    const lowStockItems = products.filter((product) => product.stock <= product.minStockLevel)

    setStats({
      totalProducts: products.length,
      totalSales: sales.length,
      totalCustomers: customers.length,
      lowStockItems: lowStockItems.length,
      todaySales: todaySales.length,
      totalRevenue,
    })
  }, [])

  const statCards = [
    {
      title: "Total Products",
      value: stats.totalProducts,
      icon: Package,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
    },
    {
      title: "Total Sales",
      value: stats.totalSales,
      icon: ShoppingCart,
      color: "text-green-600",
      bgColor: "bg-green-50",
    },
    {
      title: "Total Customers",
      value: stats.totalCustomers,
      icon: Users,
      color: "text-purple-600",
      bgColor: "bg-purple-50",
    },
    {
      title: "Low Stock Items",
      value: stats.lowStockItems,
      icon: TrendingUp,
      color: "text-red-600",
      bgColor: "bg-red-50",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, index) => {
          const Icon = stat.icon
          return (
            <Card key={index}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">{stat.title}</CardTitle>
                <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                  <Icon className={`h-4 w-4 ${stat.color}`} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Today's Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Sales Today</span>
                <span className="font-semibold">{stats.todaySales}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Total Revenue</span>
                <span className="font-semibold">${stats.totalRevenue.toFixed(2)}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Inventory Alerts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {stats.lowStockItems > 0 ? (
                <div className="flex items-center space-x-2 text-red-600">
                  <TrendingUp className="h-4 w-4" />
                  <span>{stats.lowStockItems} items are running low on stock</span>
                </div>
              ) : (
                <div className="text-green-600">All items are well stocked</div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
