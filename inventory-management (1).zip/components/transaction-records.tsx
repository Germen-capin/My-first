"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { db } from "@/lib/database"
import type { Transaction, Sale, Purchase, Customer, Supplier } from "@/lib/types"
import { TrendingUp, TrendingDown, DollarSign, Calendar, Filter, Download } from "lucide-react"

export function TransactionRecords() {
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>([])
  const [sales, setSales] = useState<Sale[]>([])
  const [purchases, setPurchases] = useState<Purchase[]>([])
  const [customers, setCustomers] = useState<Customer[]>([])
  const [suppliers, setSuppliers] = useState<Supplier[]>([])
  const [filterType, setFilterType] = useState("all")
  const [dateFrom, setDateFrom] = useState("")
  const [dateTo, setDateTo] = useState("")
  const [searchTerm, setSearchTerm] = useState("")

  useEffect(() => {
    loadData()
  }, [])

  useEffect(() => {
    applyFilters()
  }, [transactions, filterType, dateFrom, dateTo, searchTerm])

  const loadData = () => {
    const allTransactions = db.getTransactions()
    const allSales = db.getSales()
    const allPurchases = db.getPurchases()
    const allCustomers = db.getCustomers()
    const allSuppliers = db.getSuppliers()

    setTransactions(allTransactions)
    setSales(allSales)
    setPurchases(allPurchases)
    setCustomers(allCustomers)
    setSuppliers(allSuppliers)
  }

  const applyFilters = () => {
    let filtered = [...transactions]

    // Filter by type
    if (filterType !== "all") {
      filtered = filtered.filter((transaction) => transaction.type === filterType)
    }

    // Filter by date range
    if (dateFrom) {
      const fromDate = new Date(dateFrom)
      filtered = filtered.filter((transaction) => new Date(transaction.date) >= fromDate)
    }
    if (dateTo) {
      const toDate = new Date(dateTo)
      toDate.setHours(23, 59, 59, 999) // End of day
      filtered = filtered.filter((transaction) => new Date(transaction.date) <= toDate)
    }

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(
        (transaction) =>
          transaction.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
          transaction.referenceId.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // Sort by date (newest first)
    filtered.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())

    setFilteredTransactions(filtered)
  }

  const getTransactionTypeBadge = (type: string) => {
    switch (type) {
      case "sale":
        return (
          <Badge variant="default" className="bg-green-500">
            Sale
          </Badge>
        )
      case "purchase":
        return (
          <Badge variant="secondary" className="bg-blue-500 text-white">
            Purchase
          </Badge>
        )
      default:
        return <Badge variant="outline">{type}</Badge>
    }
  }

  const calculateStats = () => {
    const today = new Date()
    const thisMonth = new Date(today.getFullYear(), today.getMonth(), 1)
    const thisYear = new Date(today.getFullYear(), 0, 1)

    const salesTransactions = transactions.filter((t) => t.type === "sale")
    const purchaseTransactions = transactions.filter((t) => t.type === "purchase")

    const totalSalesRevenue = salesTransactions.reduce((sum, t) => sum + t.amount, 0)
    const totalPurchaseCosts = purchaseTransactions.reduce((sum, t) => sum + t.amount, 0)

    const monthlySales = salesTransactions
      .filter((t) => new Date(t.date) >= thisMonth)
      .reduce((sum, t) => sum + t.amount, 0)

    const monthlyPurchases = purchaseTransactions
      .filter((t) => new Date(t.date) >= thisMonth)
      .reduce((sum, t) => sum + t.amount, 0)

    const todaySales = salesTransactions
      .filter((t) => {
        const transactionDate = new Date(t.date)
        return (
          transactionDate.getDate() === today.getDate() &&
          transactionDate.getMonth() === today.getMonth() &&
          transactionDate.getFullYear() === today.getFullYear()
        )
      })
      .reduce((sum, t) => sum + t.amount, 0)

    return {
      totalSalesRevenue,
      totalPurchaseCosts,
      netProfit: totalSalesRevenue - totalPurchaseCosts,
      monthlySales,
      monthlyPurchases,
      todaySales,
      totalTransactions: transactions.length,
    }
  }

  const stats = calculateStats()

  const exportTransactions = () => {
    const csvContent = [
      ["Date", "Type", "Reference ID", "Amount", "Description"].join(","),
      ...filteredTransactions.map((transaction) =>
        [
          new Date(transaction.date).toLocaleDateString(),
          transaction.type,
          transaction.referenceId,
          transaction.amount.toFixed(2),
          `"${transaction.description}"`,
        ].join(","),
      ),
    ].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `transactions_${new Date().toISOString().split("T")[0]}.csv`
    a.click()
    window.URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Transaction Records</h1>
          <p className="text-gray-600 mt-2">View all transaction history and financial reports</p>
        </div>
        <Button onClick={exportTransactions} variant="outline">
          <Download className="mr-2 h-4 w-4" />
          Export CSV
        </Button>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Sales Revenue</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">${stats.totalSalesRevenue.toFixed(2)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Purchase Costs</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">${stats.totalPurchaseCosts.toFixed(2)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Net Profit</CardTitle>
            <DollarSign className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${stats.netProfit >= 0 ? "text-green-600" : "text-red-600"}`}>
              ${stats.netProfit.toFixed(2)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Today's Sales</CardTitle>
            <Calendar className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">${stats.todaySales.toFixed(2)}</div>
          </CardContent>
        </Card>
      </div>

      {/* Monthly Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>This Month Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Sales Revenue</span>
                <span className="font-semibold text-green-600">${stats.monthlySales.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Purchase Costs</span>
                <span className="font-semibold text-red-600">${stats.monthlyPurchases.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center border-t pt-2">
                <span className="font-medium">Monthly Profit</span>
                <span
                  className={`font-bold ${
                    stats.monthlySales - stats.monthlyPurchases >= 0 ? "text-green-600" : "text-red-600"
                  }`}
                >
                  ${(stats.monthlySales - stats.monthlyPurchases).toFixed(2)}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Transaction Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Total Transactions</span>
                <span className="font-semibold">{stats.totalTransactions}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Sales Transactions</span>
                <span className="font-semibold text-green-600">
                  {transactions.filter((t) => t.type === "sale").length}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Purchase Transactions</span>
                <span className="font-semibold text-blue-600">
                  {transactions.filter((t) => t.type === "purchase").length}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Filter className="mr-2 h-5 w-5" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label htmlFor="type-filter">Transaction Type</Label>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger>
                  <SelectValue placeholder="All types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="sale">Sales</SelectItem>
                  <SelectItem value="purchase">Purchases</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="date-from">From Date</Label>
              <Input id="date-from" type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="date-to">To Date</Label>
              <Input id="date-to" type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="search">Search</Label>
              <Input
                id="search"
                placeholder="Search transactions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Transaction History */}
      <Card>
        <CardHeader>
          <CardTitle>Transaction History</CardTitle>
          <CardDescription>
            Showing {filteredTransactions.length} of {transactions.length} transactions
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Reference ID</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Amount</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTransactions.map((transaction) => (
                  <TableRow key={transaction.id}>
                    <TableCell>{new Date(transaction.date).toLocaleString()}</TableCell>
                    <TableCell>{getTransactionTypeBadge(transaction.type)}</TableCell>
                    <TableCell className="font-mono text-sm">#{transaction.referenceId.slice(-6)}</TableCell>
                    <TableCell>{transaction.description}</TableCell>
                    <TableCell>
                      <span
                        className={`font-medium ${transaction.type === "sale" ? "text-green-600" : "text-red-600"}`}
                      >
                        {transaction.type === "sale" ? "+" : "-"}${transaction.amount.toFixed(2)}
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          {filteredTransactions.length === 0 && (
            <div className="text-center py-8">
              <p className="text-gray-500">No transactions found matching your criteria.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
