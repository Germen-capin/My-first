"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { createCashierAccount, getAllCashiers } from "@/lib/auth"
import type { User } from "@/lib/types"
import { Plus, Eye, Copy, Check } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export function CashierManagement() {
  const [cashiers, setCashiers] = useState<User[]>([])
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isDetailsDialogOpen, setIsDetailsDialogOpen] = useState(false)
  const [selectedCashier, setSelectedCashier] = useState<User | null>(null)
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    image: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    loadCashiers()
  }, [])

  const loadCashiers = () => {
    const loadedCashiers = getAllCashiers()
    setCashiers(loadedCashiers)
  }

  const resetForm = () => {
    setFormData({
      name: "",
      email: "",
      password: "",
      image: "",
    })
  }

  const handleCreateCashier = async () => {
    if (!formData.name || !formData.email || !formData.password) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    try {
      const result = await createCashierAccount(
        formData.email,
        formData.password,
        formData.name,
        formData.image || undefined,
      )

      if (result.success) {
        toast({
          title: "Success",
          description: `Cashier account created! ID: ${result.cashierId}`,
        })
        loadCashiers()
        setIsAddDialogOpen(false)
        resetForm()
      } else {
        toast({
          title: "Error",
          description: result.message,
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create cashier account",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const copyToClipboard = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedId(id)
      toast({
        title: "Copied!",
        description: "Cashier ID copied to clipboard",
      })
      setTimeout(() => setCopiedId(null), 2000)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy to clipboard",
        variant: "destructive",
      })
    }
  }

  const viewCashierDetails = (cashier: User) => {
    setSelectedCashier(cashier)
    setIsDetailsDialogOpen(true)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Cashier Management</h1>
          <p className="text-gray-600 mt-2">Create and manage cashier accounts</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button
              onClick={() => {
                resetForm()
                setIsAddDialogOpen(true)
              }}
            >
              <Plus className="mr-2 h-4 w-4" />
              Create Cashier Account
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Create New Cashier Account</DialogTitle>
              <DialogDescription>
                Enter the details for the new cashier. A unique 8-digit ID will be generated.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="cashier-name">Full Name *</Label>
                <Input
                  id="cashier-name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Enter full name"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cashier-email">Email *</Label>
                <Input
                  id="cashier-email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="Enter email address"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cashier-password">Password *</Label>
                <Input
                  id="cashier-password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  placeholder="Enter password"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cashier-image">Profile Image URL (Optional)</Label>
                <Input
                  id="cashier-image"
                  type="url"
                  value={formData.image}
                  onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                  placeholder="Enter image URL"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleCreateCashier} disabled={isLoading}>
                {isLoading ? "Creating..." : "Create Account"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Total Cashiers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{cashiers.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Active Accounts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{cashiers.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Recent Additions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {
                cashiers.filter((c) => {
                  const createdDate = new Date(c.createdAt)
                  const weekAgo = new Date()
                  weekAgo.setDate(weekAgo.getDate() - 7)
                  return createdDate > weekAgo
                }).length
              }
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Cashiers Table */}
      <Card>
        <CardHeader>
          <CardTitle>Cashier Accounts</CardTitle>
          <CardDescription>{cashiers.length} cashier accounts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Profile</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Cashier ID</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {cashiers.map((cashier) => (
                  <TableRow key={cashier.id}>
                    <TableCell>
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={cashier.image || "/placeholder.svg"} alt={cashier.name} />
                        <AvatarFallback>
                          {cashier.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")
                            .toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                    </TableCell>
                    <TableCell className="font-medium">{cashier.name}</TableCell>
                    <TableCell>{cashier.email}</TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <code className="bg-gray-100 px-2 py-1 rounded text-sm font-mono">{cashier.cashierId}</code>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyToClipboard(cashier.cashierId || "", cashier.id)}
                        >
                          {copiedId === cashier.id ? (
                            <Check className="h-4 w-4 text-green-600" />
                          ) : (
                            <Copy className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </TableCell>
                    <TableCell>{new Date(cashier.createdAt).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <Badge variant="default">Active</Badge>
                    </TableCell>
                    <TableCell>
                      <Button variant="outline" size="sm" onClick={() => viewCashierDetails(cashier)}>
                        <Eye className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Cashier Details Dialog */}
      <Dialog open={isDetailsDialogOpen} onOpenChange={setIsDetailsDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Cashier Details</DialogTitle>
            <DialogDescription>Account information and credentials</DialogDescription>
          </DialogHeader>
          {selectedCashier && (
            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                <Avatar className="h-16 w-16">
                  <AvatarImage src={selectedCashier.image || "/placeholder.svg"} alt={selectedCashier.name} />
                  <AvatarFallback className="text-lg">
                    {selectedCashier.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")
                      .toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-semibold text-lg">{selectedCashier.name}</h3>
                  <p className="text-gray-600">{selectedCashier.email}</p>
                  <Badge variant="default">Cashier</Badge>
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <Label className="text-sm font-medium">Cashier ID</Label>
                  <div className="flex items-center space-x-2 mt-1">
                    <code className="bg-gray-100 px-3 py-2 rounded text-sm font-mono flex-1">
                      {selectedCashier.cashierId}
                    </code>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(selectedCashier.cashierId || "", selectedCashier.id)}
                    >
                      {copiedId === selectedCashier.id ? (
                        <Check className="h-4 w-4 text-green-600" />
                      ) : (
                        <Copy className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Cashiers can use this ID to login if they forget their password
                  </p>
                </div>

                <div>
                  <Label className="text-sm font-medium">Account Created</Label>
                  <p className="text-sm text-gray-600 mt-1">{new Date(selectedCashier.createdAt).toLocaleString()}</p>
                </div>

                <div>
                  <Label className="text-sm font-medium">Login Methods</Label>
                  <div className="text-sm text-gray-600 mt-1 space-y-1">
                    <p>• Email: {selectedCashier.email}</p>
                    <p>• Cashier ID: {selectedCashier.cashierId}</p>
                  </div>
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button onClick={() => setIsDetailsDialogOpen(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
