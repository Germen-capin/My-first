"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { db } from "@/lib/database"
import type { Product, Purchase, PurchaseItem, Supplier, Transaction } from "@/lib/types"
import { Plus, Minus, ShoppingBag, Eye, X } from "lucide-react"

export function PurchaseManagement() {
  const [products, setProducts] = useState<Product[]>([])
  const [suppliers, setSuppliers] = useState<Supplier[]>([])
  const [purchases, setPurchases] = useState<Purchase[]>([])
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [isNewPurchaseDialogOpen, setIsNewPurchaseDialogOpen] = useState(false)
  const [isPurchaseDetailsDialogOpen, setIsPurchaseDetailsDialogOpen] = useState(false)
  const [selectedPurchase, setSelectedPurchase] = useState<Purchase | null>(null)
  const [cart, setCart] = useState<PurchaseItem[]>([])
  const [selectedSupplierId, setSelectedSupplierId] = useState("")

  useEffect(() => {
    loadData()
  }, [])

  useEffect(() => {
    const filtered = products.filter(
      (product) =>
        product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.category.toLowerCase().includes(searchTerm.toLowerCase()),
    )
    setFilteredProducts(filtered)
  }, [products, searchTerm])

  const loadData = () => {
    setProducts(db.getProducts())
    setSuppliers(db.getSuppliers())
    setPurchases(db.getPurchases())
  }

  const addToCart = (product: Product) => {
    const existingItem = cart.find((item) => item.productId === product.id)
    if (existingItem) {
      setCart(
        cart.map((item) =>
          item.productId === product.id
            ? { ...item, quantity: item.quantity + 1, subtotal: (item.quantity + 1) * item.unitCost }
            : item,
        ),
      )
    } else {
      const newItem: PurchaseItem = {
        id: Date.now().toString(),
        productId: product.id,
        product,
        quantity: 1,
        unitCost: product.price * 0.7, // Assume purchase cost is 70% of selling price
        subtotal: product.price * 0.7,
      }
      setCart([...cart, newItem])
    }
  }

  const removeFromCart = (productId: string) => {
    const existingItem = cart.find((item) => item.productId === productId)
    if (existingItem && existingItem.quantity > 1) {
      setCart(
        cart.map((item) =>
          item.productId === productId
            ? { ...item, quantity: item.quantity - 1, subtotal: (item.quantity - 1) * item.unitCost }
            : item,
        ),
      )
    } else {
      setCart(cart.filter((item) => item.productId !== productId))
    }
  }

  const updateItemCost = (productId: string, newCost: number) => {
    setCart(
      cart.map((item) =>
        item.productId === productId ? { ...item, unitCost: newCost, subtotal: item.quantity * newCost } : item,
      ),
    )
  }

  const clearCart = () => {
    setCart([])
    setSelectedSupplierId("")
  }

  const calculateTotal = () => {
    return cart.reduce((sum, item) => sum + item.subtotal, 0)
  }

  const processPurchase = () => {
    if (cart.length === 0 || !selectedSupplierId) return

    const newPurchase: Purchase = {
      id: Date.now().toString(),
      supplierId: selectedSupplierId,
      items: cart,
      totalCost: calculateTotal(),
      purchaseDate: new Date(),
      status: "received", // Automatically mark as received for simplicity
    }

    // Save purchase
    db.savePurchase(newPurchase)

    // Update product stock
    cart.forEach((item) => {
      const product = products.find((p) => p.id === item.productId)
      if (product) {
        const updatedProduct = {
          ...product,
          stock: product.stock + item.quantity,
          updatedAt: new Date(),
        }
        db.saveProduct(updatedProduct)
      }
    })

    // Create transaction record
    const transaction: Transaction = {
      id: Date.now().toString(),
      type: "purchase",
      referenceId: newPurchase.id,
      amount: newPurchase.totalCost,
      date: new Date(),
      description: `Purchase from ${suppliers.find((s) => s.id === selectedSupplierId)?.name}`,
    }
    db.saveTransaction(transaction)

    // Refresh data and clear cart
    loadData()
    clearCart()
    setIsNewPurchaseDialogOpen(false)
  }

  const getPurchaseStatusBadge = (status: string) => {
    switch (status) {
      case "received":
        return <Badge variant="default">Received</Badge>
      case "pending":
        return <Badge variant="secondary">Pending</Badge>
      case "cancelled":
        return <Badge variant="destructive">Cancelled</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const viewPurchaseDetails = (purchase: Purchase) => {
    setSelectedPurchase(purchase)
    setIsPurchaseDetailsDialogOpen(true)
  }

  const getLowStockProducts = () => {
    return products.filter((product) => product.stock <= product.minStockLevel)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Purchase Management</h1>
          <p className="text-gray-600 mt-2">Manage supplier purchases and inventory restocking</p>
        </div>
        <Dialog open={isNewPurchaseDialogOpen} onOpenChange={setIsNewPurchaseDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setIsNewPurchaseDialogOpen(true)}>
              <ShoppingBag className="mr-2 h-4 w-4" />
              New Purchase
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create New Purchase Order</DialogTitle>
              <DialogDescription>Select products and supplier to create a purchase order.</DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Product Selection */}
              <div className="space-y-4">
                <div>
                  <Label htmlFor="product-search">Search Products</Label>
                  <Input
                    id="product-search"
                    placeholder="Search products..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <div className="max-h-96 overflow-y-auto border rounded-lg">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Product</TableHead>
                        <TableHead>Current Stock</TableHead>
                        <TableHead>Min Level</TableHead>
                        <TableHead>Action</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredProducts.map((product) => (
                        <TableRow
                          key={product.id}
                          className={product.stock <= product.minStockLevel ? "bg-red-50" : ""}
                        >
                          <TableCell>
                            <div className="flex items-center space-x-2">
                              <img
                                src={product.image || "/placeholder.svg"}
                                alt={product.name}
                                className="w-8 h-8 rounded object-cover"
                              />
                              <div>
                                <div className="font-medium text-sm">{product.name}</div>
                                <div className="text-xs text-gray-500">{product.sku}</div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <span className={product.stock <= product.minStockLevel ? "text-red-600 font-medium" : ""}>
                              {product.stock}
                            </span>
                          </TableCell>
                          <TableCell>{product.minStockLevel}</TableCell>
                          <TableCell>
                            <Button size="sm" onClick={() => addToCart(product)}>
                              <Plus className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>

              {/* Purchase Cart */}
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <Label>Purchase Order</Label>
                  <Button variant="outline" size="sm" onClick={clearCart}>
                    Clear Cart
                  </Button>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="supplier">Supplier</Label>
                  <Select value={selectedSupplierId} onValueChange={setSelectedSupplierId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select supplier" />
                    </SelectTrigger>
                    <SelectContent>
                      {suppliers.map((supplier) => (
                        <SelectItem key={supplier.id} value={supplier.id}>
                          {supplier.name} - {supplier.email}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="max-h-64 overflow-y-auto border rounded-lg p-4">
                  {cart.length === 0 ? (
                    <p className="text-center text-gray-500">Cart is empty</p>
                  ) : (
                    <div className="space-y-2">
                      {cart.map((item) => (
                        <div key={item.id} className="space-y-2 p-2 bg-gray-50 rounded">
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <div className="font-medium text-sm">{item.product.name}</div>
                              <div className="text-xs text-gray-500">Current stock: {item.product.stock}</div>
                            </div>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setCart(cart.filter((c) => c.id !== item.id))}
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Button size="sm" variant="outline" onClick={() => removeFromCart(item.productId)}>
                              <Minus className="h-3 w-3" />
                            </Button>
                            <span className="text-sm font-medium px-2">{item.quantity}</span>
                            <Button size="sm" variant="outline" onClick={() => addToCart(item.product)}>
                              <Plus className="h-3 w-3" />
                            </Button>
                            <Input
                              type="number"
                              step="0.01"
                              value={item.unitCost}
                              onChange={(e) => updateItemCost(item.productId, Number.parseFloat(e.target.value) || 0)}
                              className="w-20 text-sm"
                              placeholder="Cost"
                            />
                            <div className="text-sm font-medium">${item.subtotal.toFixed(2)}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <div className="flex justify-between font-bold text-lg">
                  <span>Total Cost:</span>
                  <span>${calculateTotal().toFixed(2)}</span>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsNewPurchaseDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={processPurchase} disabled={cart.length === 0 || !selectedSupplierId}>
                Create Purchase Order
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Low Stock Alert */}
      {getLowStockProducts().length > 0 && (
        <Card className="border-red-200 bg-red-50">
          <CardHeader>
            <CardTitle className="text-red-800">Low Stock Alert</CardTitle>
            <CardDescription className="text-red-600">
              {getLowStockProducts().length} products are running low on stock and need restocking.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
              {getLowStockProducts()
                .slice(0, 6)
                .map((product) => (
                  <div key={product.id} className="flex items-center justify-between p-2 bg-white rounded border">
                    <div>
                      <div className="font-medium text-sm">{product.name}</div>
                      <div className="text-xs text-gray-500">
                        Stock: {product.stock} / Min: {product.minStockLevel}
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        addToCart(product)
                        setIsNewPurchaseDialogOpen(true)
                      }}
                    >
                      Restock
                    </Button>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Purchase History */}
      <Card>
        <CardHeader>
          <CardTitle>Purchase History</CardTitle>
          <CardDescription>{purchases.length} total purchases</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Purchase ID</TableHead>
                  <TableHead>Supplier</TableHead>
                  <TableHead>Items</TableHead>
                  <TableHead>Total Cost</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {purchases.map((purchase) => {
                  const supplier = suppliers.find((s) => s.id === purchase.supplierId)
                  return (
                    <TableRow key={purchase.id}>
                      <TableCell className="font-medium">#{purchase.id.slice(-6)}</TableCell>
                      <TableCell>{supplier?.name || "Unknown"}</TableCell>
                      <TableCell>{purchase.items.length} items</TableCell>
                      <TableCell className="font-medium">${purchase.totalCost.toFixed(2)}</TableCell>
                      <TableCell>{new Date(purchase.purchaseDate).toLocaleDateString()}</TableCell>
                      <TableCell>{getPurchaseStatusBadge(purchase.status)}</TableCell>
                      <TableCell>
                        <Button variant="outline" size="sm" onClick={() => viewPurchaseDetails(purchase)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Purchase Details Dialog */}
      <Dialog open={isPurchaseDetailsDialogOpen} onOpenChange={setIsPurchaseDetailsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Purchase Details</DialogTitle>
            <DialogDescription>Purchase #{selectedPurchase?.id.slice(-6)}</DialogDescription>
          </DialogHeader>
          {selectedPurchase && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Supplier</Label>
                  <p>{suppliers.find((s) => s.id === selectedPurchase.supplierId)?.name}</p>
                </div>
                <div>
                  <Label>Date</Label>
                  <p>{new Date(selectedPurchase.purchaseDate).toLocaleString()}</p>
                </div>
                <div>
                  <Label>Status</Label>
                  <div>{getPurchaseStatusBadge(selectedPurchase.status)}</div>
                </div>
                <div>
                  <Label>Total Cost</Label>
                  <p className="font-bold">${selectedPurchase.totalCost.toFixed(2)}</p>
                </div>
              </div>
              <div>
                <Label>Items</Label>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Product</TableHead>
                      <TableHead>Quantity</TableHead>
                      <TableHead>Unit Cost</TableHead>
                      <TableHead>Subtotal</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedPurchase.items.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell>{item.product.name}</TableCell>
                        <TableCell>{item.quantity}</TableCell>
                        <TableCell>${item.unitCost.toFixed(2)}</TableCell>
                        <TableCell>${item.subtotal.toFixed(2)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button onClick={() => setIsPurchaseDetailsDialogOpen(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
