"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { db } from "@/lib/database"
import type { Sale } from "@/lib/types"
import { getCurrentUser } from "@/lib/auth"
import { Eye } from "lucide-react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"

export function CustomerPurchases() {
  const [purchases, setPurchases] = useState<Sale[]>([])
  const [selectedPurchase, setSelectedPurchase] = useState<Sale | null>(null)
  const [isDetailsDialogOpen, setIsDetailsDialogOpen] = useState(false)
  const user = getCurrentUser()

  useEffect(() => {
    if (user) {
      const allSales = db.getSales()
      const userPurchases = allSales.filter((sale) => sale.customerId === user.id)
      setPurchases(userPurchases)
    }
  }, [user])

  const viewPurchaseDetails = (purchase: Sale) => {
    setSelectedPurchase(purchase)
    setIsDetailsDialogOpen(true)
  }

  const getSaleStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge variant="default">Completed</Badge>
      case "pending":
        return <Badge variant="secondary">Pending</Badge>
      case "cancelled":
        return <Badge variant="destructive">Cancelled</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">My Purchases</h1>
        <p className="text-gray-600 mt-2">View your purchase history and order details</p>
      </div>

      {/* Purchase History */}
      <Card>
        <CardHeader>
          <CardTitle>Purchase History</CardTitle>
          <CardDescription>{purchases.length} total purchases</CardDescription>
        </CardHeader>
        <CardContent>
          {purchases.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500">You haven't made any purchases yet.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Order ID</TableHead>
                    <TableHead>Items</TableHead>
                    <TableHead>Total</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {purchases.map((purchase) => (
                    <TableRow key={purchase.id}>
                      <TableCell className="font-medium">#{purchase.id.slice(-6)}</TableCell>
                      <TableCell>{purchase.items.length} items</TableCell>
                      <TableCell className="font-medium">${purchase.total.toFixed(2)}</TableCell>
                      <TableCell>{new Date(purchase.saleDate).toLocaleDateString()}</TableCell>
                      <TableCell>{getSaleStatusBadge(purchase.status)}</TableCell>
                      <TableCell>
                        <Button variant="outline" size="sm" onClick={() => viewPurchaseDetails(purchase)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Purchase Details Dialog */}
      <Dialog open={isDetailsDialogOpen} onOpenChange={setIsDetailsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Purchase Details</DialogTitle>
            <DialogDescription>Order #{selectedPurchase?.id.slice(-6)}</DialogDescription>
          </DialogHeader>
          {selectedPurchase && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium">Order Date</h4>
                  <p>{new Date(selectedPurchase.saleDate).toLocaleString()}</p>
                </div>
                <div>
                  <h4 className="font-medium">Status</h4>
                  <div>{getSaleStatusBadge(selectedPurchase.status)}</div>
                </div>
                <div>
                  <h4 className="font-medium">Subtotal</h4>
                  <p>${selectedPurchase.subtotal.toFixed(2)}</p>
                </div>
                <div>
                  <h4 className="font-medium">Total</h4>
                  <p className="font-bold text-lg">${selectedPurchase.total.toFixed(2)}</p>
                </div>
              </div>
              <div>
                <h4 className="font-medium mb-2">Items Purchased</h4>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Product</TableHead>
                      <TableHead>Quantity</TableHead>
                      <TableHead>Unit Price</TableHead>
                      <TableHead>Subtotal</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedPurchase.items.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <img
                              src={item.product.image || "/placeholder.svg"}
                              alt={item.product.name}
                              className="w-8 h-8 rounded object-cover"
                            />
                            <span>{item.product.name}</span>
                          </div>
                        </TableCell>
                        <TableCell>{item.quantity}</TableCell>
                        <TableCell>${item.unitPrice.toFixed(2)}</TableCell>
                        <TableCell>${item.subtotal.toFixed(2)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
