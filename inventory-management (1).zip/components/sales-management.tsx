"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { db } from "@/lib/database"
import type { Product, Sale, SaleItem, Customer, Transaction } from "@/lib/types"
import { Plus, Minus, ShoppingCart, Eye, X } from "lucide-react"

export function SalesManagement() {
  const [products, setProducts] = useState<Product[]>([])
  const [customers, setCustomers] = useState<Customer[]>([])
  const [sales, setSales] = useState<Sale[]>([])
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [isNewSaleDialogOpen, setIsNewSaleDialogOpen] = useState(false)
  const [isSaleDetailsDialogOpen, setIsSaleDetailsDialogOpen] = useState(false)
  const [selectedSale, setSelectedSale] = useState<Sale | null>(null)
  const [cart, setCart] = useState<SaleItem[]>([])
  const [selectedCustomerId, setSelectedCustomerId] = useState("")
  const [discount, setDiscount] = useState(0)

  useEffect(() => {
    loadData()
  }, [])

  useEffect(() => {
    const filtered = products.filter(
      (product) =>
        product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.category.toLowerCase().includes(searchTerm.toLowerCase()),
    )
    setFilteredProducts(filtered)
  }, [products, searchTerm])

  const loadData = () => {
    setProducts(db.getProducts())
    setCustomers(db.getCustomers())
    setSales(db.getSales())
  }

  const addToCart = (product: Product) => {
    const existingItem = cart.find((item) => item.productId === product.id)
    if (existingItem) {
      if (existingItem.quantity < product.stock) {
        setCart(
          cart.map((item) =>
            item.productId === product.id
              ? { ...item, quantity: item.quantity + 1, subtotal: (item.quantity + 1) * item.unitPrice }
              : item,
          ),
        )
      }
    } else {
      if (product.stock > 0) {
        const newItem: SaleItem = {
          id: Date.now().toString(),
          productId: product.id,
          product,
          quantity: 1,
          unitPrice: product.price,
          subtotal: product.price,
        }
        setCart([...cart, newItem])
      }
    }
  }

  const removeFromCart = (productId: string) => {
    const existingItem = cart.find((item) => item.productId === productId)
    if (existingItem && existingItem.quantity > 1) {
      setCart(
        cart.map((item) =>
          item.productId === productId
            ? { ...item, quantity: item.quantity - 1, subtotal: (item.quantity - 1) * item.unitPrice }
            : item,
        ),
      )
    } else {
      setCart(cart.filter((item) => item.productId !== productId))
    }
  }

  const clearCart = () => {
    setCart([])
    setSelectedCustomerId("")
    setDiscount(0)
  }

  const calculateSubtotal = () => {
    return cart.reduce((sum, item) => sum + item.subtotal, 0)
  }

  const calculateTotal = () => {
    const subtotal = calculateSubtotal()
    return subtotal - discount
  }

  const processSale = () => {
    if (cart.length === 0 || !selectedCustomerId) return

    const newSale: Sale = {
      id: Date.now().toString(),
      customerId: selectedCustomerId,
      items: cart,
      subtotal: calculateSubtotal(),
      discount,
      total: calculateTotal(),
      saleDate: new Date(),
      status: "completed",
    }

    // Save sale
    db.saveSale(newSale)

    // Update product stock
    cart.forEach((item) => {
      const product = products.find((p) => p.id === item.productId)
      if (product) {
        const updatedProduct = {
          ...product,
          stock: product.stock - item.quantity,
          updatedAt: new Date(),
        }
        db.saveProduct(updatedProduct)
      }
    })

    // Create transaction record
    const transaction: Transaction = {
      id: Date.now().toString(),
      type: "sale",
      referenceId: newSale.id,
      amount: newSale.total,
      date: new Date(),
      description: `Sale to ${customers.find((c) => c.id === selectedCustomerId)?.name}`,
    }
    db.saveTransaction(transaction)

    // Refresh data and clear cart
    loadData()
    clearCart()
    setIsNewSaleDialogOpen(false)
  }

  const getSaleStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge variant="default">Completed</Badge>
      case "pending":
        return <Badge variant="secondary">Pending</Badge>
      case "cancelled":
        return <Badge variant="destructive">Cancelled</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const viewSaleDetails = (sale: Sale) => {
    setSelectedSale(sale)
    setIsSaleDetailsDialogOpen(true)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Sales Management</h1>
          <p className="text-gray-600 mt-2">Process sales and view sales history</p>
        </div>
        <Dialog open={isNewSaleDialogOpen} onOpenChange={setIsNewSaleDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setIsNewSaleDialogOpen(true)}>
              <ShoppingCart className="mr-2 h-4 w-4" />
              New Sale
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Process New Sale</DialogTitle>
              <DialogDescription>Select products and customer to process a sale.</DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Product Selection */}
              <div className="space-y-4">
                <div>
                  <Label htmlFor="product-search">Search Products</Label>
                  <Input
                    id="product-search"
                    placeholder="Search products..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <div className="max-h-96 overflow-y-auto border rounded-lg">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Product</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Stock</TableHead>
                        <TableHead>Action</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredProducts.map((product) => (
                        <TableRow key={product.id}>
                          <TableCell>
                            <div className="flex items-center space-x-2">
                              <img
                                src={product.image || "/placeholder.svg"}
                                alt={product.name}
                                className="w-8 h-8 rounded object-cover"
                              />
                              <div>
                                <div className="font-medium text-sm">{product.name}</div>
                                <div className="text-xs text-gray-500">{product.sku}</div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>${product.price.toFixed(2)}</TableCell>
                          <TableCell>{product.stock}</TableCell>
                          <TableCell>
                            <Button size="sm" onClick={() => addToCart(product)} disabled={product.stock === 0}>
                              <Plus className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>

              {/* Cart */}
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <Label>Shopping Cart</Label>
                  <Button variant="outline" size="sm" onClick={clearCart}>
                    Clear Cart
                  </Button>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="customer">Customer</Label>
                  <Select value={selectedCustomerId} onValueChange={setSelectedCustomerId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select customer" />
                    </SelectTrigger>
                    <SelectContent>
                      {customers.map((customer) => (
                        <SelectItem key={customer.id} value={customer.id}>
                          {customer.name} - {customer.email}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="max-h-64 overflow-y-auto border rounded-lg p-4">
                  {cart.length === 0 ? (
                    <p className="text-center text-gray-500">Cart is empty</p>
                  ) : (
                    <div className="space-y-2">
                      {cart.map((item) => (
                        <div key={item.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                          <div className="flex-1">
                            <div className="font-medium text-sm">{item.product.name}</div>
                            <div className="text-xs text-gray-500">
                              ${item.unitPrice.toFixed(2)} × {item.quantity}
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Button size="sm" variant="outline" onClick={() => removeFromCart(item.productId)}>
                              <Minus className="h-3 w-3" />
                            </Button>
                            <span className="text-sm font-medium">{item.quantity}</span>
                            <Button size="sm" variant="outline" onClick={() => addToCart(item.product)}>
                              <Plus className="h-3 w-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setCart(cart.filter((c) => c.id !== item.id))}
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          </div>
                          <div className="text-sm font-medium ml-2">${item.subtotal.toFixed(2)}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>${calculateSubtotal().toFixed(2)}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Label htmlFor="discount">Discount:</Label>
                    <Input
                      id="discount"
                      type="number"
                      step="0.01"
                      value={discount}
                      onChange={(e) => setDiscount(Number.parseFloat(e.target.value) || 0)}
                      className="w-24"
                    />
                  </div>
                  <div className="flex justify-between font-bold text-lg">
                    <span>Total:</span>
                    <span>${calculateTotal().toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsNewSaleDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={processSale} disabled={cart.length === 0 || !selectedCustomerId}>
                Process Sale
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Sales History */}
      <Card>
        <CardHeader>
          <CardTitle>Sales History</CardTitle>
          <CardDescription>{sales.length} total sales</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Sale ID</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Items</TableHead>
                  <TableHead>Subtotal</TableHead>
                  <TableHead>Discount</TableHead>
                  <TableHead>Total</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sales.map((sale) => {
                  const customer = customers.find((c) => c.id === sale.customerId)
                  return (
                    <TableRow key={sale.id}>
                      <TableCell className="font-medium">#{sale.id.slice(-6)}</TableCell>
                      <TableCell>{customer?.name || "Unknown"}</TableCell>
                      <TableCell>{sale.items.length} items</TableCell>
                      <TableCell>${sale.subtotal.toFixed(2)}</TableCell>
                      <TableCell>${sale.discount.toFixed(2)}</TableCell>
                      <TableCell className="font-medium">${sale.total.toFixed(2)}</TableCell>
                      <TableCell>{new Date(sale.saleDate).toLocaleDateString()}</TableCell>
                      <TableCell>{getSaleStatusBadge(sale.status)}</TableCell>
                      <TableCell>
                        <Button variant="outline" size="sm" onClick={() => viewSaleDetails(sale)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Sale Details Dialog */}
      <Dialog open={isSaleDetailsDialogOpen} onOpenChange={setIsSaleDetailsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Sale Details</DialogTitle>
            <DialogDescription>Sale #{selectedSale?.id.slice(-6)}</DialogDescription>
          </DialogHeader>
          {selectedSale && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Customer</Label>
                  <p>{customers.find((c) => c.id === selectedSale.customerId)?.name}</p>
                </div>
                <div>
                  <Label>Date</Label>
                  <p>{new Date(selectedSale.saleDate).toLocaleString()}</p>
                </div>
                <div>
                  <Label>Status</Label>
                  <div>{getSaleStatusBadge(selectedSale.status)}</div>
                </div>
                <div>
                  <Label>Total</Label>
                  <p className="font-bold">${selectedSale.total.toFixed(2)}</p>
                </div>
              </div>
              <div>
                <Label>Items</Label>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Product</TableHead>
                      <TableHead>Quantity</TableHead>
                      <TableHead>Unit Price</TableHead>
                      <TableHead>Subtotal</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedSale.items.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell>{item.product.name}</TableCell>
                        <TableCell>{item.quantity}</TableCell>
                        <TableCell>${item.unitPrice.toFixed(2)}</TableCell>
                        <TableCell>${item.subtotal.toFixed(2)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button onClick={() => setIsSaleDetailsDialogOpen(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
