"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { db } from "@/lib/database"
import type { Product, SaleItem, Sale, Transaction } from "@/lib/types"
import { Plus, Minus, ShoppingCart, X } from "lucide-react"
import { getCurrentUser } from "@/lib/auth"

export function CustomerShopping() {
  const [products, setProducts] = useState<Product[]>([])
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [cart, setCart] = useState<SaleItem[]>([])
  const [selectedCategory, setSelectedCategory] = useState("all")
  const user = getCurrentUser()

  useEffect(() => {
    loadProducts()
  }, [])

  useEffect(() => {
    let filtered = products.filter(
      (product) =>
        product.stock > 0 && // Only show products in stock
        (product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          product.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
          product.brand.toLowerCase().includes(searchTerm.toLowerCase())),
    )

    if (selectedCategory !== "all") {
      filtered = filtered.filter((product) => product.category === selectedCategory)
    }

    setFilteredProducts(filtered)
  }, [products, searchTerm, selectedCategory])

  const loadProducts = () => {
    setProducts(db.getProducts())
  }

  const getCategories = () => {
    const categories = [...new Set(products.map((p) => p.category))]
    return categories
  }

  const addToCart = (product: Product) => {
    const existingItem = cart.find((item) => item.productId === product.id)
    if (existingItem) {
      if (existingItem.quantity < product.stock) {
        setCart(
          cart.map((item) =>
            item.productId === product.id
              ? { ...item, quantity: item.quantity + 1, subtotal: (item.quantity + 1) * item.unitPrice }
              : item,
          ),
        )
      }
    } else {
      const newItem: SaleItem = {
        id: Date.now().toString(),
        productId: product.id,
        product,
        quantity: 1,
        unitPrice: product.price,
        subtotal: product.price,
      }
      setCart([...cart, newItem])
    }
  }

  const removeFromCart = (productId: string) => {
    const existingItem = cart.find((item) => item.productId === productId)
    if (existingItem && existingItem.quantity > 1) {
      setCart(
        cart.map((item) =>
          item.productId === productId
            ? { ...item, quantity: item.quantity - 1, subtotal: (item.quantity - 1) * item.unitPrice }
            : item,
        ),
      )
    } else {
      setCart(cart.filter((item) => item.productId !== productId))
    }
  }

  const clearCart = () => {
    setCart([])
  }

  const calculateTotal = () => {
    return cart.reduce((sum, item) => sum + item.subtotal, 0)
  }

  const getCartQuantity = (productId: string) => {
    const item = cart.find((item) => item.productId === productId)
    return item ? item.quantity : 0
  }

  const checkout = () => {
    if (cart.length === 0 || !user) return

    const newSale: Sale = {
      id: Date.now().toString(),
      customerId: user.id,
      items: cart,
      subtotal: calculateTotal(),
      discount: 0,
      total: calculateTotal(),
      saleDate: new Date(),
      status: "completed",
    }

    // Save sale
    db.saveSale(newSale)

    // Update product stock
    cart.forEach((item) => {
      const product = products.find((p) => p.id === item.productId)
      if (product) {
        const updatedProduct = {
          ...product,
          stock: product.stock - item.quantity,
          updatedAt: new Date(),
        }
        db.saveProduct(updatedProduct)
      }
    })

    // Create transaction record
    const transaction: Transaction = {
      id: Date.now().toString(),
      type: "sale",
      referenceId: newSale.id,
      amount: newSale.total,
      date: new Date(),
      description: `Purchase by ${user.name}`,
    }
    db.saveTransaction(transaction)

    // Refresh products and clear cart
    loadProducts()
    clearCart()
    alert("Purchase completed successfully!")
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Shop Products</h1>
        <p className="text-gray-600 mt-2">Browse and purchase products from our inventory</p>
      </div>

      {/* Search and Filters */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2">
          <Label htmlFor="search">Search Products</Label>
          <Input
            id="search"
            placeholder="Search by name, category, or brand..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="mt-1"
          />
        </div>
        <div>
          <Label htmlFor="category">Category</Label>
          <select
            id="category"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Categories</option>
            {getCategories().map((category) => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Products Grid */}
        <div className="lg:col-span-3">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product) => {
              const cartQuantity = getCartQuantity(product.id)
              return (
                <Card key={product.id} className="overflow-hidden">
                  <div className="aspect-square bg-gray-100 flex items-center justify-center">
                    <img
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">{product.name}</CardTitle>
                    <CardDescription>
                      <div className="flex justify-between items-center">
                        <span>{product.brand}</span>
                        <Badge variant="outline">{product.category}</Badge>
                      </div>
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <p className="text-sm text-gray-600 line-clamp-2">{product.description}</p>
                      <div className="flex justify-between items-center">
                        <span className="text-2xl font-bold text-blue-600">${product.price.toFixed(2)}</span>
                        <span className="text-sm text-gray-500">Stock: {product.stock}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        {cartQuantity > 0 ? (
                          <div className="flex items-center space-x-2">
                            <Button size="sm" variant="outline" onClick={() => removeFromCart(product.id)}>
                              <Minus className="h-4 w-4" />
                            </Button>
                            <span className="font-medium px-3">{cartQuantity}</span>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => addToCart(product)}
                              disabled={cartQuantity >= product.stock}
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>
                        ) : (
                          <Button onClick={() => addToCart(product)} disabled={product.stock === 0} className="w-full">
                            <Plus className="mr-2 h-4 w-4" />
                            Add to Cart
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
          {filteredProducts.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500">No products found matching your criteria.</p>
            </div>
          )}
        </div>

        {/* Shopping Cart */}
        <div className="lg:col-span-1">
          <Card className="sticky top-6">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="flex items-center">
                  <ShoppingCart className="mr-2 h-5 w-5" />
                  Cart ({cart.length})
                </CardTitle>
                {cart.length > 0 && (
                  <Button variant="outline" size="sm" onClick={clearCart}>
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {cart.length === 0 ? (
                <p className="text-center text-gray-500 py-4">Your cart is empty</p>
              ) : (
                <div className="space-y-4">
                  <div className="max-h-64 overflow-y-auto space-y-2">
                    {cart.map((item) => (
                      <div key={item.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-sm truncate">{item.product.name}</div>
                          <div className="text-xs text-gray-500">
                            ${item.unitPrice.toFixed(2)} × {item.quantity}
                          </div>
                        </div>
                        <div className="text-sm font-medium">${item.subtotal.toFixed(2)}</div>
                      </div>
                    ))}
                  </div>
                  <div className="border-t pt-4">
                    <div className="flex justify-between items-center font-bold text-lg">
                      <span>Total:</span>
                      <span>${calculateTotal().toFixed(2)}</span>
                    </div>
                    <Button onClick={checkout} className="w-full mt-4">
                      Checkout
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
