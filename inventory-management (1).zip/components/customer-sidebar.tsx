"use client"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { logout, getCurrentUser } from "@/lib/auth"
import { ShoppingCart, ShoppingBag, Package, LogOut } from "lucide-react"

interface CustomerSidebarProps {
  activeSection: string
  onSectionChange: (section: string) => void
}

export function CustomerSidebar({ activeSection, onSectionChange }: CustomerSidebarProps) {
  const router = useRouter()
  const user = getCurrentUser()

  const handleLogout = () => {
    logout()
    router.push("/")
  }

  const menuItems = [
    { id: "sales", label: "Sales", icon: ShoppingCart },
    { id: "purchases", label: "Purchases", icon: ShoppingBag },
    { id: "inventory", label: "Inventory", icon: Package },
  ]

  return (
    <div className="w-64 bg-gradient-to-b from-blue-600 via-blue-700 to-blue-800 text-white min-h-screen flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-blue-500">
        <h1 className="text-2xl font-bold text-white">MEGRAC</h1>
        <p className="text-blue-200 text-sm mt-1">Customer Portal</p>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <div className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon
            const isActive = activeSection === item.id

            return (
              <Button
                key={item.id}
                variant={isActive ? "secondary" : "ghost"}
                className={`w-full justify-start text-left h-12 ${
                  isActive
                    ? "bg-yellow-400 text-black hover:bg-yellow-500"
                    : "text-white hover:bg-blue-600 hover:text-white"
                }`}
                onClick={() => onSectionChange(item.id)}
              >
                <Icon className="mr-3 h-5 w-5" />
                {item.label}
              </Button>
            )
          })}
        </div>
      </nav>

      {/* User Info & Logout */}
      <div className="p-4 border-t border-blue-500">
        <div className="mb-3">
          <p className="text-sm text-blue-200">Logged in as:</p>
          <p className="font-medium text-white">{user?.name}</p>
          <p className="text-xs text-blue-300 capitalize">{user?.role}</p>
        </div>
        <Button
          variant="destructive"
          className="w-full justify-start bg-red-600 hover:bg-red-700"
          onClick={handleLogout}
        >
          <LogOut className="mr-3 h-4 w-4" />
          Sign Out
        </Button>
      </div>
    </div>
  )
}
