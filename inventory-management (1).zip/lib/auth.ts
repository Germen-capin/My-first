import type { User } from "./types"

let currentUser: User | null = null

const mockUsers: User[] = [
  {
    id: "1",
    email: "megracadmin@gmail.com", // Updated admin email
    name: "Admin User",
    role: "admin",
    password: "admin123",
    createdAt: new Date(),
  },
]

const generateCashierId = (): string => {
  return Math.floor(10000000 + Math.random() * 90000000).toString()
}

const loadUsers = (): User[] => {
  if (typeof window !== "undefined") {
    const stored = localStorage.getItem("registeredUsers")
    if (stored) {
      const users = JSON.parse(stored)
      // Always ensure admin user exists with updated email
      const hasAdmin = users.some((u: User) => u.email === "megracadmin@gmail.com")
      if (!hasAdmin) {
        users.unshift(mockUsers[0])
      }
      return users
    }
  }
  return [...mockUsers]
}

const saveUsers = (users: User[]) => {
  if (typeof window !== "undefined") {
    localStorage.setItem("registeredUsers", JSON.stringify(users))
  }
}

export const createCashierAccount = async (
  email: string,
  password: string,
  name: string,
  image?: string,
): Promise<{ success: boolean; message: string; user?: User; cashierId?: string }> => {
  const users = loadUsers()

  // Check if email already exists
  if (users.some((u) => u.email === email)) {
    return { success: false, message: "Email already exists" }
  }

  const cashierId = generateCashierId()

  // Ensure unique cashier ID
  while (users.some((u) => u.cashierId === cashierId)) {
    const newCashierId = generateCashierId()
    if (newCashierId !== cashierId) break
  }

  const newUser: User = {
    id: Date.now().toString(),
    email,
    name,
    role: "cashier",
    password,
    cashierId,
    image,
    createdAt: new Date(),
  }

  users.push(newUser)
  saveUsers(users)

  return {
    success: true,
    message: "Cashier account created successfully",
    user: newUser,
    cashierId,
  }
}

export const register = async (
  email: string,
  password: string,
  name: string,
  role: "customer" = "customer",
): Promise<{ success: boolean; message: string; user?: User }> => {
  const users = loadUsers()

  // Check if email already exists
  if (users.some((u) => u.email === email)) {
    return { success: false, message: "Email already exists" }
  }

  const newUser: User = {
    id: Date.now().toString(),
    email,
    name,
    role,
    password,
    createdAt: new Date(),
  }

  users.push(newUser)
  saveUsers(users)

  return { success: true, message: "Account created successfully", user: newUser }
}

export const login = async (
  emailOrId: string,
  password: string,
  loginType: "admin" | "cashier" | "customer" = "customer",
): Promise<User | null> => {
  const users = loadUsers()

  let user: User | undefined

  if (loginType === "admin") {
    user = users.find((u) => u.email === emailOrId && u.role === "admin")
  } else if (loginType === "cashier") {
    // Check if it's an email or cashier ID in the first parameter
    user = users.find((u) => u.role === "cashier" && (u.email === emailOrId || u.cashierId === emailOrId))

    // If user found by email, check if password is actually a cashier ID
    if (user && user.email === emailOrId) {
      // Check if password field contains cashier ID
      if (user.cashierId === password) {
        // Login with email + cashier ID combination
        currentUser = user
        localStorage.setItem("currentUser", JSON.stringify(user))
        return user
      }
    }
  } else {
    user = users.find((u) => u.email === emailOrId && u.role === "customer")
  }

  if (!user) return null

  let isValidPassword = false

  if (user.role === "admin" && password === "admin123") {
    isValidPassword = true
  } else if (user.password === password) {
    isValidPassword = true
  }

  if (isValidPassword) {
    currentUser = user
    localStorage.setItem("currentUser", JSON.stringify(user))
    return user
  }

  return null
}

export const logout = () => {
  currentUser = null
  localStorage.removeItem("currentUser")
}

export const getCurrentUser = (): User | null => {
  if (currentUser) return currentUser

  // Try to get from localStorage
  if (typeof window !== "undefined") {
    const stored = localStorage.getItem("currentUser")
    if (stored) {
      currentUser = JSON.parse(stored)
      return currentUser
    }
  }

  return null
}

export const isAuthenticated = (): boolean => {
  return getCurrentUser() !== null
}

export const hasRole = (role: "admin" | "cashier" | "customer"): boolean => {
  const user = getCurrentUser()
  return user?.role === role
}

export const isAdminOrCashier = (): boolean => {
  const user = getCurrentUser()
  return user?.role === "admin" || user?.role === "cashier"
}

export const getAllUsers = (): User[] => {
  const currentUser = getCurrentUser()
  if (currentUser?.role !== "admin") return []
  return loadUsers()
}

export const getAllCashiers = (): User[] => {
  const currentUser = getCurrentUser()
  if (currentUser?.role !== "admin") return []
  const users = loadUsers()
  return users.filter((u) => u.role === "cashier")
}

export const getAllCustomers = (): User[] => {
  const currentUser = getCurrentUser()
  if (currentUser?.role !== "admin") return []
  const users = loadUsers()
  return users.filter((u) => u.role === "customer")
}
