// User types
export interface User {
  id: string
  email: string
  name: string
  role: "admin" | "cashier" | "customer"
  password?: string // Added password field for registration
  cashierId?: string // Unique 8-digit ID for cashiers
  image?: string // Profile image for cashiers
  createdAt: Date
}

// Product types
export interface Product {
  id: string
  sku: string
  name: string
  category: string
  brand: string
  description: string
  price: number
  unit: string
  stock: number
  minStockLevel: number
  image?: string
  barcode?: string
  location?: string
  createdAt: Date
  updatedAt: Date
}

// Sale types
export interface Sale {
  id: string
  customerId: string
  items: SaleItem[]
  subtotal: number
  discount: number
  total: number
  saleDate: Date
  status: "pending" | "completed" | "cancelled"
}

export interface SaleItem {
  id: string
  productId: string
  product: Product
  quantity: number
  unitPrice: number
  subtotal: number
}

// Purchase types
export interface Purchase {
  id: string
  supplierId: string
  items: PurchaseItem[]
  totalCost: number
  purchaseDate: Date
  status: "pending" | "received" | "cancelled"
}

export interface PurchaseItem {
  id: string
  productId: string
  product: Product
  quantity: number
  unitCost: number
  subtotal: number
}

// Customer types
export interface Customer {
  id: string
  name: string
  email: string
  phone?: string
  address?: string
  createdAt: Date
}

// Supplier types
export interface Supplier {
  id: string
  name: string
  email: string
  phone?: string
  address?: string
  createdAt: Date
}

// Transaction types
export interface Transaction {
  id: string
  type: "sale" | "purchase"
  referenceId: string
  amount: number
  date: Date
  description: string
}
