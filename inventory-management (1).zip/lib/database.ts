import type { Product, Sale, Purchase, Customer, Supplier, Transaction } from "./types"

// Mock database using localStorage
class MockDatabase {
  private getFromStorage<T>(key: string): T[] {
    if (typeof window === "undefined") return []
    const data = localStorage.getItem(key)
    return data ? JSON.parse(data) : []
  }

  private saveToStorage<T>(key: string, data: T[]): void {
    if (typeof window === "undefined") return
    localStorage.setItem(key, JSON.stringify(data))
  }

  // Products
  getProducts(): Product[] {
    return this.getFromStorage<Product>("products")
  }

  saveProduct(product: Product): void {
    const products = this.getProducts()
    const index = products.findIndex((p) => p.id === product.id)
    if (index >= 0) {
      products[index] = product
    } else {
      products.push(product)
    }
    this.saveToStorage("products", products)
  }

  deleteProduct(id: string): void {
    const products = this.getProducts().filter((p) => p.id !== id)
    this.saveToStorage("products", products)
  }

  // Sales
  getSales(): Sale[] {
    return this.getFromStorage<Sale>("sales")
  }

  saveSale(sale: Sale): void {
    const sales = this.getSales()
    const index = sales.findIndex((s) => s.id === sale.id)
    if (index >= 0) {
      sales[index] = sale
    } else {
      sales.push(sale)
    }
    this.saveToStorage("sales", sales)
  }

  // Purchases
  getPurchases(): Purchase[] {
    return this.getFromStorage<Purchase>("purchases")
  }

  savePurchase(purchase: Purchase): void {
    const purchases = this.getPurchases()
    const index = purchases.findIndex((p) => p.id === purchase.id)
    if (index >= 0) {
      purchases[index] = purchase
    } else {
      purchases.push(purchase)
    }
    this.saveToStorage("purchases", purchases)
  }

  // Customers
  getCustomers(): Customer[] {
    return this.getFromStorage<Customer>("customers")
  }

  saveCustomer(customer: Customer): void {
    const customers = this.getCustomers()
    const index = customers.findIndex((c) => c.id === customer.id)
    if (index >= 0) {
      customers[index] = customer
    } else {
      customers.push(customer)
    }
    this.saveToStorage("customers", customers)
  }

  // Suppliers
  getSuppliers(): Supplier[] {
    return this.getFromStorage<Supplier>("suppliers")
  }

  saveSupplier(supplier: Supplier): void {
    const suppliers = this.getSuppliers()
    const index = suppliers.findIndex((s) => s.id === supplier.id)
    if (index >= 0) {
      suppliers[index] = supplier
    } else {
      suppliers.push(supplier)
    }
    this.saveToStorage("suppliers", suppliers)
  }

  // Transactions
  getTransactions(): Transaction[] {
    return this.getFromStorage<Transaction>("transactions")
  }

  saveTransaction(transaction: Transaction): void {
    const transactions = this.getTransactions()
    transactions.push(transaction)
    this.saveToStorage("transactions", transactions)
  }

  // Initialize with sample data
  initializeSampleData(): void {
    if (this.getProducts().length === 0) {
      const sampleProducts: Product[] = [
        {
          id: "1",
          sku: "LAP001",
          name: "Gaming Laptop",
          category: "Electronics",
          brand: "TechBrand",
          description: "High-performance gaming laptop with RTX graphics",
          price: 1299.99,
          unit: "piece",
          stock: 15,
          minStockLevel: 5,
          image: "/gaming-laptop.png",
          barcode: "123456789012",
          location: "A1-B2",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          id: "2",
          sku: "PHN001",
          name: "Smartphone",
          category: "Electronics",
          brand: "PhoneBrand",
          description: "Latest smartphone with advanced camera",
          price: 699.99,
          unit: "piece",
          stock: 25,
          minStockLevel: 10,
          image: "/modern-smartphone.png",
          barcode: "123456789013",
          location: "A2-B1",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          id: "3",
          sku: "TAB001",
          name: "Tablet",
          category: "Electronics",
          brand: "TabletBrand",
          description: "10-inch tablet for productivity and entertainment",
          price: 399.99,
          unit: "piece",
          stock: 20,
          minStockLevel: 8,
          image: "/modern-tablet.png",
          barcode: "123456789014",
          location: "A3-B1",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ]

      sampleProducts.forEach((product) => this.saveProduct(product))
    }

    if (this.getCustomers().length === 0) {
      const sampleCustomers: Customer[] = [
        {
          id: "1",
          name: "John Doe",
          email: "john@example.com",
          phone: "+1234567890",
          address: "123 Main St, City, State",
          createdAt: new Date(),
        },
        {
          id: "2",
          name: "Jane Smith",
          email: "jane@example.com",
          phone: "+1234567891",
          address: "456 Oak Ave, City, State",
          createdAt: new Date(),
        },
      ]

      sampleCustomers.forEach((customer) => this.saveCustomer(customer))
    }

    if (this.getSuppliers().length === 0) {
      const sampleSuppliers: Supplier[] = [
        {
          id: "1",
          name: "Tech Supplier Inc.",
          email: "contact@techsupplier.com",
          phone: "+1234567892",
          address: "789 Business Blvd, City, State",
          createdAt: new Date(),
        },
        {
          id: "2",
          name: "Electronics Wholesale",
          email: "sales@electronicswholesale.com",
          phone: "+1234567893",
          address: "321 Industrial Way, City, State",
          createdAt: new Date(),
        },
      ]

      sampleSuppliers.forEach((supplier) => this.saveSupplier(supplier))
    }
  }
}

export const db = new MockDatabase()
